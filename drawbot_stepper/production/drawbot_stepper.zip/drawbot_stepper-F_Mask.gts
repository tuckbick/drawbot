G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-04-02T13:05:05-05:00*
G04 #@! TF.ProjectId,drawbot_stepper,64726177-626f-4745-9f73-746570706572,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-04-02 13:05:05*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.250001X-0.799999X-0.799999X0.799999X-0.799999X0.799999X0.799999X-0.799999X0.799999X0*%
%ADD11C,2.100000*%
%ADD12C,3.000000*%
%ADD13C,3.250000*%
%ADD14R,1.800000X1.800000*%
%ADD15C,1.800000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J1*
X61735000Y-79100000D03*
D11*
X66735000Y-79100000D03*
X71735000Y-79100000D03*
X76735000Y-79100000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,N1*
X76980000Y-64250000D03*
D13*
X74950000Y-61200000D03*
X63520000Y-61200000D03*
D12*
X61490000Y-64250000D03*
D14*
X73680000Y-67550000D03*
D15*
X72410000Y-70090000D03*
X71140000Y-67550000D03*
X69870000Y-70090000D03*
X68600000Y-67550000D03*
X67330000Y-70090000D03*
X66060000Y-67550000D03*
X64790000Y-70090000D03*
G04 #@! TD*
M02*
